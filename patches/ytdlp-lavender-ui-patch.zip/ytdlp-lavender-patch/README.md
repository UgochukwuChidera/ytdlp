# YT-DLP Lavender UI first-pass patch

This patch keeps the existing Vue 3 + Vite application. It adds a custom design layer inspired by the supplied lavender/ivory reference: soft lavender canvas, warm off-white panels, deep plum outlines, yellow primary actions, consistent radii and offset shadows, and a dark-theme equivalent.

## Apply

1. Copy `frontend/src/assets/styles/theme.css` into the repository at the same path.
2. In `frontend/src/main.js`, add this import **after** the existing `base.css` import:

   `import './assets/styles/theme.css'`

3. Run the frontend build: `cd frontend && npm run build`.
4. Review the Download, Library, Subscriptions and Settings screens in both light and dark mode, and at desktop/mobile widths.

The patch does not change download logic, API calls, routing, or persisted settings. It is a visual foundation, not the final UX audit: the next pass should replace inconsistent native `title` tooltips, improve advanced-settings disclosure and tune page-specific spacing after a browser review.
